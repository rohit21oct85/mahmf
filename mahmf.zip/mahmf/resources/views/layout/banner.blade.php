   <div class="container">
        <div class="header-nav">
            <nav class="navbar navbar-default">
            <!-- Brand and toggle get grouped for better mobile display -->
            <div class="navbar-header">
                <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#bs-example-navbar-collapse-1">
                    <span class="sr-only">Toggle navigation</span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                    <span class="icon-bar"></span>
                </button>
                <h1> <a class="navbar-brand" href="{{ url('/') }}">
                        {{ config('app.name', 'MAHMF') }}
                    </a></h1>
            </div>
            <!-- Collect the nav links, forms, and other content for toggling -->
            <div class="collapse navbar-collapse nav-wil" id="bs-example-navbar-collapse-1">
                <ul class="nav navbar-nav nav1 cl-effect-11" id="cl-effect-11">
                    <li><a data-hover="HOME" class="scroll active" href="{{ url('/') }}">HOME</a></li>
                    <li>/</li>
                    <li><a data-hover="ABOUT" class="scroll" href="#about">ABOUT</a></li>
                    <li>/</li>
                    <li><a  data-hover="GALLERY" class="scroll"  href="#gallery">GALLERY</a></li>
                    <li>/</li>
                    <li><a  data-hover="TEAM" class="scroll" href="#team">TEAM</a></li>
                    <li>/</li>
                    <li><a data-hover="SERVICES" class="scroll" href="#services">SERVICES</a></li>
                    <li>/</li>
                    <li><a data-hover="CONTACT" class="scroll" href="#contact">CONTACT</a></li>
                    @if (Route::has('login'))
           
                @auth
                <li>/</li>
                    <li><a data-hover="HOME" class="scroll" href="{{ url('/home') }}">HOME</a></li>
                    <li>/</li>
                @else
                    <li>/</li>
                    <li><a data-hover="LOGIN" href="{{ route('login') }}">LOGIN</a></li>
                    <li>/</li>
                    <li><a data-hover="REGISTER" href="{{ route('register') }}">REGISTER</a></li>
                @endauth
            
            @endif
                </ul>
            
            </div><!-- /navbar-collapse -->
            <div class="clearfix"></div>

            </nav>

        </div>
        <div class="banner-info">
            <div class="logo-text">
                <h3>{{ config('app.name', 'MAHMF') }}</h3>
                <br>
                <p>Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium 
                                doloremque laudantium, totam rem aperiam, eaque ipsa quae ab.</p>
                <p>Perspiciatis unde omnis iste natus error sit voluptatem accusantium 
                                doloremque laudantium, totam rem.</p>
                <a class="scroll" href="#about"><img src="images/arr1.png" alt="" /></a>
            </div>
        </div>
    </div>