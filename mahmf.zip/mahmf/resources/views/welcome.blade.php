<!doctype html>
<html lang="{{ app()->getLocale() }}">
<head>
@include('layout.head')
</head>
<body>
<!-- banner -->
<div class="banner">
    @include('layout.banner')
</div>
<!-- //banner -->
<!-- about -->
<div id="about" class="about">
    <div class="container">
        <div class="col-md-3 about-left text-center">
            <h3>About</h3>
        </div>
        <div class="col-md-9 about-right">
            <p>Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium 
                doloremque laudantium, totam rem aperiam, eaque ipsa quae ab.Perspiciatis unde omnis iste natus error sit voluptatem accusantium 
                                doloremque laudantium, totam rem.</p>
        </div>
        <div class="clearfix"></div>
        <div class="abt-btm">
            <div class="col-md-2 abt-btm-left">
                <div class="hi-icon-wrap hi-icon-effect-7 hi-icon-effect-7b">
                    <a href="#" class="hi-icon glyphicon glyphicon-heart"></a>
                </div>
            </div>
            <div class="col-md-5 abt-btm-middle">
                <h4>Our Story</h4>
                <h5>Perspiciatis unde omnis iste natus error sit voluptatem</h5>
                <p>Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium 
                doloremque laudantium, totam rem aperiam, eaque ipsa quae ab.Perspiciatis unde omnis iste natus error sit voluptatem accusantium 
                                doloremque laudantium, totam rem.</p>
            </div>
            <div class="col-md-5 abt-btm-right mask">
                <img src="images/11.jpg" alt=""  class="img-responsive zoom-img">
            </div>
            <div class="clearfix"></div>
        </div>
    </div>
</div>
<!-- //about -->
<!-- mission -->
<div class="mission-gd">
    <div class="container">
        <div class="col-md-6 mission-left ">
            <div class="mis-img-left grid mask">
                <figure class="effect-jazz">
                        <img class="img-responsive zoom-img" src="images/15.jpg" alt="img06">
                        <figcaption>
                            <h4>Charity Life</h4>
                            <p>When Jazz starts to chase cars, the whole world stands still.</p>
                    
                        </figcaption>           
                </figure>
            </div>
            
        </div>
        <div class="col-md-6 mission-left grid-right-miss">
            <div class="miss-left-gd text-left">
                <div class="hi-icon-wrap hi-icon-effect-7 hi-icon-effect-7b">
                    <a href="#" class="hi-icon glyphicon glyphicon-star"></a>
                </div>
            </div>
            <div class="miss-right-gd">
                <h4>Our Mission</h4>
                <p>Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium 
                doloremque laudantium, totam rem aperiam, eaque ipsa quae.</p>
            </div>
            <div class="clearfix"></div>
            <div class="progress-gds">
                <h5>Doloremque / 60%</h5>
                <div class="progress">
                    <div class="progress-bar" role="progressbar" aria-valuenow="60" aria-valuemin="0" aria-valuemax="100" style="width: 60%;">

                    </div>
                </div>
                <h5>Laudantium / 45%</h5>
                <div class="progress">
                    <div class="progress-bar" role="progressbar" aria-valuenow="60" aria-valuemin="0" aria-valuemax="100" style="width: 45%;">
                    </div>
                </div>
                <h5>Perspiciatis / 15%</h5>
                <div class="progress">
                    <div class="progress-bar" role="progressbar" aria-valuenow="60" aria-valuemin="0" aria-valuemax="100" style="width: 15%;">
                    </div>
                </div>
                
            </div>
        </div>
        <div class="clearfix"></div>
    </div>
</div>
<!-- mission -->
<div class="simple">
    <div class="container">
        <h3>Help turn tears to smiles,together we create a special world.</h3>
        <div class="strip"></div>
        <p>Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium 
                doloremque laudantium, totam rem aperiam, eaque ipsa quae ab.Perspiciatis unde omnis iste natus error sit voluptatem accusantium 
                                doloremque laudantium, totam rem</p>
    </div>
</div>
<!-- services -->
<!-- team -->
<div id="team" class="team">
    <div class="container">
        <div class="col-md-3 about-left text-center">
            <h3>Team</h3>
        </div>
        <div class="col-md-9 about-right">
            <p>Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium 
                doloremque laudantium, totam rem aperiam, eaque ipsa quae ab.Perspiciatis unde omnis iste natus error sit voluptatem accusantium 
                                doloremque laudantium, totam rem.</p>
        </div>
        <div class="clearfix"></div>
        <div class="team-grids">
            <div class="col-md-3 team-grid text-center">
                <div class="team-img">
                     <!-- normal -->
                    <div class="ih-item circle effect1"><a href="#">
                        <div class="spinner"></div>
                        <div class="img"><img src="images/team1.jpg" alt="img"></div>
                        <div class="info">
                          <div class="info-back">
                          </div>
                        </div></a></div>
                    <!-- end normal -->
                    <h4>Federica</h4>
                    <h5>Designer</h5>
                    <p>Nam libero tempore, cum soluta nobis
                    est eligendi optio cumque nihil </p>
                    <ul>
                        <li><a class="fb" href="#"></a></li>
                        <li><a class="twitt" href="#"></a></li>
                        <li><a class="goog" href="#"></a></li>
                        <li><a class="drib" href="#"></a></li>
                    </ul>
                </div>
            </div>
            <div class="col-md-3 team-grid text-center">
                <div class="team-img">
                     <!-- normal -->
                    <div class="ih-item circle effect1"><a href="#">
                        <div class="spinner"></div>
                        <div class="img"><img src="images/team2.jpg" alt="img"></div>
                        <div class="info">
                          <div class="info-back">
                          </div>
                        </div></a></div>
                    <!-- end normal -->
                    <h4>Hokkins</h4>
                    <h5>Co-founder</h5>
                    <p>Nam libero tempore, cum soluta nobis
                    est eligendi optio cumque nihil </p>
                    <ul>
                        <li><a class="fb" href="#"></a></li>
                        <li><a class="twitt" href="#"></a></li>
                        <li><a class="goog" href="#"></a></li>
                        <li><a class="drib" href="#"></a></li>
                    </ul>
                </div>
            </div>
            <div class="col-md-3 team-grid text-center">
                <div class="team-img">
                     <!-- normal -->
                    <div class="ih-item circle effect1"><a href="#">
                        <div class="spinner"></div>
                        <div class="img"><img src="images/team3.jpg" alt="img"></div>
                        <div class="info">
                          <div class="info-back">
                          </div>
                        </div></a></div>
                    <!-- end normal -->
                    <h4>Albert</h4>
                    <h5>Manager</h5>
                    <p>Nam libero tempore, cum soluta nobis
                    est eligendi optio cumque nihil</p>
                    <ul>
                        <li><a class="fb" href="#"></a></li>
                        <li><a class="twitt" href="#"></a></li>
                        <li><a class="goog" href="#"></a></li>
                        <li><a class="drib" href="#"></a></li>
                    </ul>
                </div>
            </div>
            <div class="col-md-3 team-grid text-center">
                <div class="team-img">
                     <!-- normal -->
                    <div class="ih-item circle effect1"><a href="#">
                        <div class="spinner"></div>
                        <div class="img"><img src="images/team4.jpg" alt="img"></div>
                        <div class="info">
                          <div class="info-back">
                          </div>
                        </div></a></div>
                    <!-- end normal -->
                    <h4>Victoria</h4>
                    <h5>Developer</h5>
                    <p>Nam libero tempore, cum soluta nobis
                    est eligendi optio cumque nihil </p>
                    <ul>
                        <li><a class="fb" href="#"></a></li>
                        <li><a class="twitt" href="#"></a></li>
                        <li><a class="goog" href="#"></a></li>
                        <li><a class="drib" href="#"></a></li>
                    </ul>
                </div>
            </div>
            <div class="clearfix"></div>
        </div>
        
    </div>
</div>
<!-- //team -->

<!-- capabilities -->
<div class="capabilities">
    <div class="container">
        <div class="col-md-3 capabil-grid wow fadeInLeft animated animated text-center" data-wow-delay="0.4s">
            <div class="hi-icon-wrap hi-icon-effect-4 hi-icon-effect-4b">
                <div class="abt-icon">
                    <a href="#" class="hi-icon icon1"></a>
                </div>
            </div>
            <div class='numscroller numscroller-big-bottom' data-slno='1' data-min='0' data-max='57000' data-delay='.5' data-increment="100">57000</div>
            <h5>Voluptatem</h5>     
        </div>
        <div class="col-md-3 capabil-grid wow fadeInUpBig animated animated text-center" data-wow-delay="0.4s">
            <div class="hi-icon-wrap hi-icon-effect-4 hi-icon-effect-4b">
                <div class="abt-icon">
                    <a href="#" class="hi-icon icon2"></a>
                </div>
            </div>          
            <div class='numscroller numscroller-big-bottom' data-slno='1' data-min='0' data-max='1700' data-delay='.5' data-increment="5">1700</div>
            <h5>Laudantium</h5> 
        </div>
        <div class="col-md-3 capabil-grid wow fadeInDownBig animated animated text-center" data-wow-delay="0.4s">
            <div class="hi-icon-wrap hi-icon-effect-4 hi-icon-effect-4b">
                <div class="abt-icon">
                    <a href="#" class="hi-icon icon3"></a>
                </div>
            </div>
            <div class='numscroller numscroller-big-bottom' data-slno='1' data-min='0' data-max='90000' data-delay='.5' data-increment="100">90000</div>                
            <h5>Doloremque</h5>
        </div>
        <div class="col-md-3 capabil-grid wow fadeInRight animated animated text-center" data-wow-delay="0.4s">
            <div class="hi-icon-wrap hi-icon-effect-4 hi-icon-effect-4b">
                <div class="abt-icon">
                    <a href="#" class="hi-icon icon4"></a>
                </div>
            </div>
                        
            <div class='numscroller numscroller-big-bottom' data-slno='1' data-min='0' data-max='2500' data-delay='.5' data-increment="1">2500</div>
            <h5>Perspiciatis</h5>
        </div>
        <div class="clearfix"></div>
    </div>
</div>
<!-- capabilities -->
<!-- services -->
<div id="services" class="service-grid">
    <div class="container">
        <div class="col-md-3 about-left text-center">
            <h3>Services</h3>
        </div>
        <div class="col-md-9 about-right">
            <p>Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium 
                doloremque laudantium, totam rem aperiam, eaque ipsa quae ab.Perspiciatis unde omnis iste natus error sit voluptatem accusantium 
                                doloremque laudantium, totam rem.</p>
        </div>
        <div class="clearfix"></div>
        <div class="abt-btm">
            <div class="col-md-4 bottom-gds">
                <div class="bott-img">
                            <div class="icon-holder">
                                <span class="glyphicon glyphicon-education icon" aria-hidden="true"></span>
                            </div>
                            <h4 class="mission">Accusantium</h4>
                            <p class="description">A elementum ligula lacus ac quam ultrices a scelerisque praesent vel suspendisse scelerisque a aenean hac montes.</p>
                </div>
            </div>
            <div class="col-md-4 bottom-gds">
                <div class="bott-img">
                            <div class="icon-holder">
                                <span class="glyphicon glyphicon-home icon" aria-hidden="true"></span>
                            </div>
                            <h4 class="mission">Consequatur</h4>
                            <p class="description">A elementum ligula lacus ac quam ultrices a scelerisque praesent vel suspendisse scelerisque a aenean hac montes.</p>
                </div>
            </div>
            <div class="col-md-4 bottom-gds">
                <div class="bott-img">
                    <div class="icon-holder">
                        <span class="glyphicon glyphicon-cutlery icon" aria-hidden="true"></span>
                    </div>
                    <h4 class="mission">Reprehenderit</h4>
                    <p class="description">A elementum ligula lacus ac quam ultrices a scelerisque praesent vel suspendisse scelerisque a aenean hac montes.</p>
                </div>
            </div>
            <div class="clearfix"></div>
        </div>
    </div>
</div>
<!-- //services -->
<!-- gallery -->
<div id="gallery" class="gallery">
    <div class="container">
        <div class="col-md-3 about-left text-center">
            <h3>Gallery</h3>
        </div>
        <div class="col-md-9 about-right">
            <p>Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium 
                doloremque laudantium, totam rem aperiam, eaque ipsa quae ab.Perspiciatis unde omnis iste natus error sit voluptatem accusantium 
                                doloremque laudantium, totam rem.</p>
        </div>
        <div class="clearfix"></div>
        <div class="gal-btm">
            <div class="col-md-4 gal-gd text-center">
                <a href="images/2.jpg" class="b-link-stripe b-animate-go  swipebox">
                    <div class="charity-gal-effect slow-zoom horizontal">
                        <div class="img-box"><img src="images/2.jpg" alt=" " /></div>
                            <div class="charity-text-box">
                                <div class="charity-gal-text">
                                    <h4>Charity Life</h4>
                                    <span class="separator"></span>
                                    <p>Sit accusamus, vel blanditiis iure minima ipsa molestias minus laborum velit, nulla.</p>
                                    <span class="separator"></span>
                                </div>
                            </div>
                    </div>
                </a>
            </div>
            <div class="col-md-4 gal-gd text-center">
                <a href="images/3.jpg" class="b-link-stripe b-animate-go  swipebox">
                    <div class="charity-gal-effect slow-zoom horizontal">
                        <div class="img-box"><img src="images/3.jpg" alt=" " /></div>
                            <div class="charity-text-box">
                                <div class="charity-gal-text">
                                    <h4>Charity Life</h4>
                                    <span class="separator"></span>
                                    <p>Sit accusamus, vel blanditiis iure minima ipsa molestias minus laborum velit, nulla.</p>
                                    <span class="separator"></span>
                                </div>
                            </div>
                    </div>
                </a>
            </div>
            <div class="col-md-4 gal-gd text-center">
                <a href="images/4.jpg" class="b-link-stripe b-animate-go  swipebox">
                    <div class="charity-gal-effect slow-zoom horizontal">
                        <div class="img-box"><img src="images/4.jpg" alt=" " /></div>
                            <div class="charity-text-box">
                                <div class="charity-gal-text">
                                    <h4>Charity Life</h4>
                                    <span class="separator"></span>
                                    <p>Sit accusamus, vel blanditiis iure minima ipsa molestias minus laborum velit, nulla.</p>
                                    <span class="separator"></span>
                                </div>
                            </div>
                    </div>
                </a>
            </div>
            <div class="col-md-6 gal-gd-sec text-center">
                <a href="images/8.jpg" class="b-link-stripe b-animate-go  swipebox">
                    <div class="charity-gal-effect slow-zoom horizontal">
                        <div class="img-box"><img src="images/8.jpg" alt=" " /></div>
                            <div class="charity-text-box">
                                <div class="charity-gal-text">
                                    <h4>Charity Life</h4>
                                    <span class="separator"></span>
                                    <p>Sit accusamus, vel blanditiis iure minima ipsa molestias minus laborum velit, nulla.</p>
                                    <span class="separator"></span>
                                </div>
                            </div>
                    </div>
                </a>
            </div>
            <div class="col-md-6 gal-gd-sec text-center">
                <a href="images/7.jpg" class="b-link-stripe b-animate-go  swipebox">
                    <div class="charity-gal-effect slow-zoom horizontal">
                        <div class="img-box"><img src="images/7.jpg" alt=" " /></div>
                            <div class="charity-text-box">
                                <div class="charity-gal-text">
                                    <h4>Charity Life</h4>
                                    <span class="separator"></span>
                                    <p>Sit accusamus, vel blanditiis iure minima ipsa molestias minus laborum velit, nulla.</p>
                                    <span class="separator"></span>
                                </div>
                            </div>
                    </div>
                </a>
            </div>
            <div class="col-md-4 gal-gd text-center">
                <a href="images/10.jpg" class="b-link-stripe b-animate-go  swipebox">
                    <div class="charity-gal-effect slow-zoom horizontal">
                        <div class="img-box"><img src="images/10.jpg" alt=" " /></div>
                            <div class="charity-text-box">
                                <div class="charity-gal-text">
                                    <h4>Charity Life</h4>
                                    <span class="separator"></span>
                                    <p>Sit accusamus, vel blanditiis iure minima ipsa molestias minus laborum velit, nulla.</p>
                                    <span class="separator"></span>
                                </div>
                            </div>
                    </div>
                </a>
            </div>
            <div class="col-md-4 gal-gd text-center">
                <a href="images/11.jpg" class="b-link-stripe b-animate-go  swipebox">
                    <div class="charity-gal-effect slow-zoom horizontal">
                        <div class="img-box"><img src="images/11.jpg" alt=" " /></div>
                            <div class="charity-text-box">
                                <div class="charity-gal-text">
                                    <h4>Charity Life</h4>
                                    <span class="separator"></span>
                                    <p>Sit accusamus, vel blanditiis iure minima ipsa molestias minus laborum velit, nulla.</p>
                                    <span class="separator"></span>
                                </div>
                            </div>
                    </div>
                </a>
            </div>
            <div class="col-md-4 gal-gd text-center">
                <a href="images/12.jpg" class="b-link-stripe b-animate-go  swipebox">
                    <div class="charity-gal-effect slow-zoom horizontal">
                        <div class="img-box"><img src="images/12.jpg" alt=" " /></div>
                            <div class="charity-text-box">
                                <div class="charity-gal-text">
                                    <h4>Charity Life</h4>
                                    <span class="separator"></span>
                                    <p>Sit accusamus, vel blanditiis iure minima ipsa molestias minus laborum velit, nulla.</p>
                                    <span class="separator"></span>
                                </div>
                            </div>
                    </div>
                </a>
            </div>
            <div class="clearfix"></div>
        </div>
    </div>
</div>
<!-- //gallery -->
<!-- banner-bottom -->
<!-- contact -->
<div id="contact" class="contact-home">
    <div class="container">
        <div class="col-md-3 about-left text-center">
            <h3>Contact</h3>
        </div>
        <div class="col-md-9 about-right">
            <p>Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium 
                doloremque laudantium, totam rem aperiam, eaque ipsa quae ab.Perspiciatis unde omnis iste natus error sit voluptatem accusantium 
                                doloremque laudantium, totam rem.</p>
        </div>
        <div class="clearfix"></div>
        <div class="gal-btm">
            <div class="map-home">
                <div class="col-md-6 login-pad">
                    <h2>Drop Us A Message</h2>
                    <form>
                                <input type="text" value="Username" onfocus="this.value = '';" onblur="if (this.value == '') {this.value = 'Username';}" required="">
                                <input type="text" value="Email" onfocus="this.value = '';" onblur="if (this.value == '') {this.value = 'Email';}" required="">
                                <label class="checkbox"><input type="checkbox" name="checkbox" checked><i> </i>Subscribe in our Newsletter</label>
                                <textarea placeholder="Message" required=""></textarea>
                                <input type="submit" value="SEND">
                    </form>
                </div>
                <div class="col-md-6 drop-pad sign-gd-two">
                    <h2>Contact Info</h2>
                    <p>Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium 
                doloremque laudantium, totam rem aperiam, eaque ipsa quae ab.Perspiciatis unde omnis iste natus error sit voluptatem accusantium 
                                doloremque laudantium, totam rem.</p>
                    <ul>
                        <li><i class="glyphicon glyphicon-map-marker" aria-hidden="true"></i>Address : 1234k Avenue, 4th block, <span>Newyork City.</span></li>
                        <li><i class="glyphicon glyphicon-envelope" aria-hidden="true"></i>Email : <a href="mailto:info@example.com">info@example.com</a></li>
                        <li><i class="glyphicon glyphicon-earphone" aria-hidden="true"></i>Phone : +1234 567 567</li>
                    </ul>
                </div>
                <div class="clearfix"></div>
                <iframe src="https://www.google.com/maps/embed?pb=!1m10!1m8!1m3!1d2482.432383990807!2d0.028213999961443994!3d51.52362882484525!3m2!1i1024!2i768!4f13.1!5e0!3m2!1sen!2sin!4v1423469959819"></iframe>
            </div>
        </div>
    </div>
</div>
<!-- //contact -->
<!-- footer -->
@include('layout.footer')

</body>
</html>

